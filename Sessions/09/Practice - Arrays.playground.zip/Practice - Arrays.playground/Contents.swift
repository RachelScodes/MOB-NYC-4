import Foundation

// TODO 1 - Create an Array that contains 4 Integers and assign it to a variable.

// TODO 2 - Add another integer to the end of that array.

// TODO 3 - Add another integer into the second slot in the array.

// TODO 4 - Iterate over your Array with a for...in loop and println the elements.

// TODO 5 - Create an Array of 5 popular dog (or cat) names and assign the array to a variable.

// TODO 6 - Using the variable, get the 3rd name out of the Array.

// TODO 7 - Write a function that accepts an Array of Strings as its first argument and an integer as its second argument. The function should return the number of dog/cat names that have the number of letters indicated by the second argument. (e.g. If the second argument is 5 and you have a name "Toshi", the function should return at least 1.)

// TODO 8 - Create a class called Human that has two properties, name and age.

// TODO 9 - Create an empty array of Humans.

// TODO 10 - Create three humans. Add each one to the end of the Array as you create them.

// TODO 11 - Create an empty String and assign it to a variable. Using a loop, iterate over the Array of Humans, and for each Human, add the Human's name to the String, adding a comma + space between the names. BONUS: Don't put a comma after the last name.

// TODO 12 - Look up the average daily temperatures from the last 30 days recorded in NYC. Compute the average of those temperatures (sum divided by the number of days).

// TODO 13 - Which one of your close friends has the longest first name? Compute it using Arrays, functions, loops, and conditionals.

