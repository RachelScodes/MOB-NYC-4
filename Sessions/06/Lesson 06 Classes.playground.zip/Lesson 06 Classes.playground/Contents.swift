import Foundation

class Human {
    var name : String
    var phoneNumber : String?
    var address : String?
    var height : Double?
    
    init(name:String) {
        self.name = name
    }
    
    func call() {
        if let _phoneNumber = self.phoneNumber {
            print("Calling \(_phoneNumber)...")
        } else {
            print("Phone number not known!!! How will we find this dog's owner?!?!")
        }
    }
}






class Dog {
    var name : String
    var breed : String
    var yearBorn : Int?
    
    var owner : Human?
    
    init(name:String, breed:String) {
        self.name = name
        self.breed = breed
        print("New dog born!")
    }
    
    init(firstName:String, lastName:String) {
        self.name = "\(firstName) \(lastName)"
        self.breed = "unknown"
    }
    
    func setAge(age:Int) {
        self.yearBorn = 2015 - age
    }
    
    func bark(numTimes:Int) {
        for _ in 1...numTimes {
            print("BARK!")
        }
    }
    
    func sit() {
        print("I'm sitting!")
    }
    
    func stay() {
        print("Staying... Maybe...")
    }
    
    func getOwnersName() -> String {
        if let _owner = self.owner {
            return _owner.name
        } else {
            return "unknown"
        }
    }
}

// Instantiate a single Dog
var myDog = Dog(name:"Toshi", breed:"shiba inu")
myDog.bark(3)
myDog.sit()
myDog.stay()

// Set and get a property
myDog.name
myDog.name = "Toshi Martin"
myDog.name

myDog.setAge(2)
myDog.yearBorn

var mySistersDog = Dog(firstName:"Layla", lastName:"Key")
mySistersDog.name
mySistersDog.breed
mySistersDog.breed = "pomeranian"
mySistersDog.breed


func prettyPrint(d:Dog) -> String {
    return "The dog's name is \(d.name)."
}

prettyPrint(myDog)
prettyPrint(mySistersDog)


func breed(name:String, oneDog:Dog, otherDog:Dog) -> Dog {
    let newBreed = oneDog.breed + otherDog.breed
    let child = Dog(name:name, breed:newBreed)
    return child
}
let theWeirdOne = breed("Hammerstein", oneDog:myDog, otherDog:mySistersDog)
theWeirdOne.breed
theWeirdOne.name


// Give my dog an owner...
let me = Human(name:"William")
myDog.owner = me
myDog.getOwnersName()

mySistersDog.getOwnersName()


func add(x:Int?, y:Int?) -> Int? {
    
    guard let _ = x else { return nil }
    guard let _ = y else { return nil }
    
    // both known
    return x! + y!
}

add(1, y:2)



class Shiba : Dog {
    var temperament : String
    
    override init(name:String, breed:String) {
        print("MAKING A SHIBA!")
        self.temperament = "stubborn"
        super.init(name:name, breed:breed)
    }
}

let toshi = Shiba(name:"Doge", breed:"shiba")
prettyPrint(toshi)


/*
add 2 properties
add 2 optional properties
add 3 methods
add bodies to the methods that use the values
  one that uses a loop
  one that uses a conditional
write a function that accepts an instance of the class and computes something about it
create a new class
add a property that references an instance of the new class (Owner to a Dog, Door to a House, Project to a Task)
create a subclass of one of your classes, something more specific
  add a property
  override the initializer
  override a method
  call the function again with an instance of the derived class (subclass)
  change the reference property (line 156) to hold an instance of the derived class
*/







