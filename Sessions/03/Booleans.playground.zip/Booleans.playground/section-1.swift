// Booleans

// Bool constants
true
false

// Binary comparison operators
3 < 1
3 > 1
3 == 3
3 != 3

// And operator: &&
(1 < 3) && (3 < 5)
// Reads: 1 is less than 3 and 3 is less than 5

// Or operator: ||
(3 < 1) || (3 > 1)
// Reads 3 is less than 1 or three is greater than 1

// Not operator: !
!false
// Reads: not false

!(3 < 1)
// Reads: 3 is not less than 1
